HOW TO IMPORT/VISUALIZE DATA
a) XML files follow a strict standard and can be opened without problem with Excel, Firefox, Chrome, etc.
b) CSV files are usually opened with Excel and this guide show how to do it:
    1) Open a new Excel document.
    2) Go to "Data" tab (Excel 2007 and after) or "Data" menu (Excel 2003 and before).
    3) Choose import from "Text Source".
    4) The wizard has 3 steps, in step 1 file type "Delimited" and file origin "UTF-8".
    5) In step 2 select only "Comma" in the delimiters section, uncheck "treat consecutive delimiters as one" and check "none" for text qualifier.
    6) Step 3 can be ignored.

Once Excel shows the data you can customize it like a regular sheet (add colors, formatting, etc).