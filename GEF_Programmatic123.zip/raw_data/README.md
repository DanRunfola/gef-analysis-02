landdegradation_treatment.csv - data extract for GEF land degradation projects (447 locations) with 10km buffers
multifocalarea_treatment.csv - data extract for GEF multi focal area projects (221 locations) with 10km buffers
programmatic_treatment.csv - data extract for GEF programmatic projects (653 locations) with 10km buffers
programmatic_control.csv - data extract for GEF programmatic control points (5007 locations) with 10km buffers

raw_programmatic.csv - raw data for GEF programmatic projects

shps/programmatic_treatments - GEF programmatic treatment 10km buffers shapefile
shps/programmatic_controls - GEF programmatic control 10km buffers shapefile
